import time, os, threading



threading.Thread(target=os.system("python TrafficSimulator.py 128.111.43.22 4567 2000 6000 45")).start()
#time.sleep()
